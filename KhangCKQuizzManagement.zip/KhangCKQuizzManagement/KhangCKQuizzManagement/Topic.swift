//
//  Topic.swift
//  KhangCKQuizzManagement
//
//  Created by BVU on 5/29/23.
//

import Foundation
struct Topic {
    var symbol: String
    var name: String
}
